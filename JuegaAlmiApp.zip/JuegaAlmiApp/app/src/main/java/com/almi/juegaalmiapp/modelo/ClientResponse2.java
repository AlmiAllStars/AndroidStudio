package com.almi.juegaalmiapp.modelo;

public class ClientResponse2 {
    private boolean success;
    private String error;

    public boolean isSuccess() {
        return success;
    }

    public String getError() {
        return error;
    }
}
