package com.almi.juegaalmiapp;

public class EmailRequest {
    private String email;

    public EmailRequest(String email) {
        this.email = email;
    }

    // Getter y setter
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
